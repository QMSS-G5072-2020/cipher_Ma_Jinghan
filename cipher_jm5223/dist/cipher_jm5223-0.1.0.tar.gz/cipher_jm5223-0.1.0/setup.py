# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['cipher_jm5223']
setup_kwargs = {
    'name': 'cipher-jm5223',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'JinghanMa98',
    'author_email': 'jm5223@columbia.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
